package com.contractresearch.marketclock;

import android.content.Context;
import android.util.Log;
import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.DataMapItem;
import com.google.android.gms.wearable.PutDataMapRequest;
import com.google.android.gms.wearable.PutDataRequest;
import com.google.android.gms.wearable.Wearable;

/** Optional Play Services Data Layer syncing; both applications work without pairing. */
public final class DataBridge {
    private DataBridge(){}
    public static void push(Context c) {
        try {
            PutDataMapRequest request=PutDataMapRequest.create("/marketclock/config");
            DataMap map=request.getDataMap();
            map.putLong("stamp",System.currentTimeMillis());
            map.putInt("lead",Prefs.lead(c));
            for(String key:Prefs.settingsKeys())map.putBoolean(key,Prefs.enabled(c,key));
            for(String key:Prefs.leadKeys())map.putInt("lead_"+key,Prefs.lead(c,key));
            if(!Prefs.isWatch(c)) {
                map.putString("macro_json",Prefs.get(c).getString("macro_json","[]"));
                map.putLong("last_sync",Prefs.get(c).getLong("last_sync",0));
                map.putBoolean("bls_ok",Prefs.get(c).getBoolean("bls_ok",false));
                map.putBoolean("bea_ok",Prefs.get(c).getBoolean("bea_ok",false));
            }
            PutDataRequest put=request.asPutDataRequest().setUrgent();
            Wearable.getDataClient(c).putDataItem(put).addOnFailureListener(e->Log.w("BTCClock","Optional watch sync",e));
        } catch(Exception e){ Log.w("BTCClock","Wearable not available",e); }
    }
    public static void apply(Context c,DataMap map) {
        android.content.SharedPreferences.Editor ed=Prefs.get(c).edit();
        if(map.containsKey("lead"))ed.putInt("lead",map.getInt("lead"));
        for(String key:Prefs.settingsKeys())if(map.containsKey(key))ed.putBoolean(key,map.getBoolean(key));
        for(String key:Prefs.leadKeys())if(map.containsKey("lead_"+key))ed.putInt("lead_"+key,map.getInt("lead_"+key));
        if(map.containsKey("macro_json") && Prefs.isWatch(c)) {
            ed.putString("macro_json",map.getString("macro_json"));
            ed.putLong("last_sync",map.getLong("last_sync"));
            ed.putBoolean("bls_ok",map.getBoolean("bls_ok"));
            ed.putBoolean("bea_ok",map.getBoolean("bea_ok"));
        }
        ed.apply();Scheduler.plan(c);
    }
}
