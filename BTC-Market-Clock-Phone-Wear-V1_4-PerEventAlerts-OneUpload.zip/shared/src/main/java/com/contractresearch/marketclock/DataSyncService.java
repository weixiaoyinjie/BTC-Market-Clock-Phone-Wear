package com.contractresearch.marketclock;

import android.util.Log;
import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataMapItem;
import com.google.android.gms.wearable.WearableListenerService;

public class DataSyncService extends WearableListenerService {
    @Override public void onDataChanged(DataEventBuffer events) {
        for(DataEvent event:events) {
            if(event.getType()==DataEvent.TYPE_CHANGED && event.getDataItem().getUri().getPath().equals("/marketclock/config")){
                try { DataBridge.apply(this,DataMapItem.fromDataItem(event.getDataItem()).getDataMap()); }
                catch(Exception e){Log.w("BTCClock","Wear data handling",e);}
            }
        }
    }
}
