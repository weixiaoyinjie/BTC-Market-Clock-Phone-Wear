package com.contractresearch.marketclock;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class SystemReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){
        Scheduler.plan(c);OfficialCalendars.installJob(c);
    }
}
