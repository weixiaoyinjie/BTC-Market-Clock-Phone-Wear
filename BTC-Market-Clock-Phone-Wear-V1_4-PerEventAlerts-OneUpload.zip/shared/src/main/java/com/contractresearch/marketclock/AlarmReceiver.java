package com.contractresearch.marketclock;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import java.time.Instant;

public class AlarmReceiver extends BroadcastReceiver {
    private static final String HIGH="market_high_v1", NORMAL="market_normal_v1";
    @Override public void onReceive(Context c,Intent intent){
        if("renew".equals(intent.getAction())){Scheduler.plan(c);return;}
        String type=intent.getStringExtra("type");
        if(type==null)return;
        if(!type.equals("test") && (!Prefs.notificationsEnabled(c)||!Prefs.enabled(c,type)))return;
        if(Build.VERSION.SDK_INT>=33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        long at=intent.getLongExtra("at",System.currentTimeMillis());
        if(!type.equals("test") && System.currentTimeMillis()>at+60_000L)return; // avoid stale notifications after reboot or idle
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm==null)return;
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel h=new NotificationChannel(HIGH,"重大市场风险窗口",NotificationManager.IMPORTANCE_HIGH);
            h.setDescription("CPI、非农、FOMC、PCE 和期权到期前提醒");nm.createNotificationChannel(h);
            NotificationChannel n=new NotificationChannel(NORMAL,"日常市场时刻",NotificationManager.IMPORTANCE_DEFAULT);
            n.setDescription("资金费率和美股开收盘观察提醒");nm.createNotificationChannel(n);
        }
        String title=intent.getStringExtra("title");if(title==null)title="BTC 时间提醒";
        String detail=intent.getStringExtra("detail");if(detail==null)detail="";
        boolean high=type.equals("fomc")||type.equals("cpi")||type.equals("nfp")||type.equals("pce")||type.equals("expiry")||type.equals("test");
        int lead=Prefs.lead(c,type,Instant.ofEpochMilli(at));
        String text=type.equals("test")?detail:("提前 "+lead+" 分钟 · "+detail
                +"\n阿根廷事件 "+ClockZones.label(Instant.ofEpochMilli(at),ClockZones.ARGENTINA)
                +"\n阿根廷提醒 "+ClockZones.label(ClockZones.reminderAt(Instant.ofEpochMilli(at),lead),ClockZones.ARGENTINA)
                +"\n北京事件 "+ClockZones.label(Instant.ofEpochMilli(at),ClockZones.BEIJING)
                +"\n纽约事件 "+ClockZones.label(Instant.ofEpochMilli(at),ClockZones.NEW_YORK));
        PendingIntent open=PendingIntent.getActivity(c,1,new Intent(c,MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification note=new Notification.Builder(c,high?HIGH:NORMAL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title).setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(open).setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setWhen(System.currentTimeMillis()).setShowWhen(true).build();
        nm.notify((type+at).hashCode(),note);
    }
}
