package com.contractresearch.marketclock;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import java.time.*;
import java.util.*;

/** Only alarm broadcasts are used: no continuously running foreground service. */
public final class Scheduler {
    private Scheduler(){}
    public static synchronized void plan(Context context){
        Context c=context.getApplicationContext();
        AlarmManager manager=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(manager==null)return;
        Set<String> previous=Prefs.get(c).getStringSet("alarm_ids",Collections.emptySet());
        for(String id:previous){
            try{PendingIntent pi=make(c,id,null,0);manager.cancel(pi);pi.cancel();}catch(Exception ignored){}
        }
        Set<String> ids=new HashSet<>();
        // Reschedule 14 days of upcoming events. A rolling daily tick renews this horizon.
        Instant now=Instant.now(), horizon=now.plus(Duration.ofDays(14));
        if(Prefs.notificationsEnabled(c)) {
            for(MarketEvent e:MarketCalendar.all(c,now.minus(Duration.ofMinutes(32)),16)) {
                if(!Prefs.enabled(c,e.type))continue;
                Instant fire=ClockZones.reminderAt(e.at,Prefs.lead(c,e.type,e.at));
                if(!fire.isAfter(now.plusSeconds(1)) || fire.isAfter(horizon))continue;
                String id="event:"+e.key();
                Intent intent=new Intent(c,AlarmReceiver.class).setAction("market_event");
                intent.putExtra("title",e.title).putExtra("detail",e.detail)
                      .putExtra("at",e.at.toEpochMilli()).putExtra("type",e.type);
                schedule(manager,fire.toEpochMilli(),make(c,id,intent,PendingIntent.FLAG_UPDATE_CURRENT));
                ids.add(id);
            }
        }
        Intent tick=new Intent(c,AlarmReceiver.class).setAction("renew");
        long tickAt=System.currentTimeMillis()+12L*60*60*1000;
        String tickId="rolling_renew";
        schedule(manager,tickAt,make(c,tickId,tick,PendingIntent.FLAG_UPDATE_CURRENT));
        ids.add(tickId);
        Prefs.get(c).edit().putStringSet("alarm_ids",ids).apply();
    }
    public static void test(Context c){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am==null)return;
        Intent i=new Intent(c,AlarmReceiver.class).setAction("test");
        i.putExtra("title","提醒测试成功").putExtra("detail","本地通知工作正常")
         .putExtra("at",System.currentTimeMillis()+10_000L).putExtra("type","test");
        schedule(am,System.currentTimeMillis()+10_000L,make(c,"user_test",i,PendingIntent.FLAG_UPDATE_CURRENT));
    }
    private static PendingIntent make(Context c,String id,Intent intent,int flags){
        Intent i=intent==null?new Intent(c,AlarmReceiver.class):intent;
        i.setData(android.net.Uri.parse("marketclock://reminder/"+android.net.Uri.encode(id)));
        return PendingIntent.getBroadcast(c,id.hashCode(),i,flags|PendingIntent.FLAG_IMMUTABLE);
    }
    private static void schedule(AlarmManager manager,long at,PendingIntent pi){
        try {
            if(Build.VERSION.SDK_INT>=31 && !manager.canScheduleExactAlarms()) {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); // may be delayed by Android
            }else{
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
            }
        }catch(SecurityException e){
            Log.w("BTCClock","Exact alarm permission missing, using inexact",e);
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
        }
    }
    public static boolean exactAllowed(Context c){
        AlarmManager m=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        return m!=null && (Build.VERSION.SDK_INT<31 || m.canScheduleExactAlarms());
    }
}
