package com.contractresearch.marketclock;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Shared lightweight native Android UI: separate phone/Wear APKs, no WebView or tracking. */
public class MainActivity extends Activity {
    private static final int BG=0xff091119, CARD=0xff13212b, CARD2=0xff192c36,
            WHITE=0xffe8f6f5, SOFT=0xffa3b8bc, MINT=0xff39deca, ORANGE=0xffffc18c;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ArrayList<TextView> clockLabels=new ArrayList<>();
    private final ArrayList<MarketEvent> activeEvents=new ArrayList<>();
    private final ArrayList<TextView> countdownLabels=new ArrayList<>();
    private boolean watch;
    private LinearLayout root;
    private ScrollView scrollView;
    private boolean showSettings=false;
    private final Runnable ticker=new Runnable(){@Override public void run(){updateClocks();handler.postDelayed(this,10_000);}};

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        watch=Prefs.isWatch(this);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        OfficialCalendars.installJob(this);
        Scheduler.plan(this);
        if(Prefs.get(this).getLong("last_sync",0)==0) autoSyncFirstRun();
        render();requestNotificationPermission();
    }
    private void autoSyncFirstRun(){
        new Thread(()->{OfficialCalendars.Result r=OfficialCalendars.refresh(getApplicationContext());
            if(r.success())runOnUiThread(()->render());},"InitialCalendarSync").start();
    }
    @Override public void onResume(){super.onResume();handler.removeCallbacks(ticker);handler.post(ticker);}
    @Override public void onPause(){handler.removeCallbacks(ticker);super.onPause();}
    @Override public void onRequestPermissionsResult(int req,String[] perms,int[] results){
        super.onRequestPermissionsResult(req,perms,results);
        if(req==88){Scheduler.plan(this);render();}
    }
    private int dp(float d){return (int)(getResources().getDisplayMetrics().density*d+0.5f);}
    private GradientDrawable shape(int color,int radius){
        GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;
    }
    private TextView text(String s,int sp,int color,boolean bold){
        TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);
        if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        v.setIncludeFontPadding(true);return v;
    }
    private void padding(View v,int h,int vert){v.setPadding(dp(h),dp(vert),dp(h),dp(vert));}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private void margin(LinearLayout p,View v,int bottom){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(bottom);p.addView(v,lp);
    }
    private void render(){
        int previousScroll=scrollView==null?0:scrollView.getScrollY();
        clockLabels.clear();activeEvents.clear();countdownLabels.clear();
        // Persistent world-clock header: stays pinned while the event list scrolls.
        // This is the first visible content on both phone and Wear OS.
        LinearLayout page=col();page.setBackgroundColor(BG);setContentView(page);
        LinearLayout pinned=col();pinned.setBackground(shape(CARD,watch?12:16));
        padding(pinned,watch?11:17,watch?7:12);
        TextView clockTitle=text("阿根廷 · 北京 · 美国（纽约）",watch?10:13,SOFT,true);
        clockTitle.setGravity(Gravity.CENTER);margin(pinned,clockTitle,watch?3:6);
        addClock(pinned,"阿根廷（提醒基准）",ClockZones.ARGENTINA);
        addClock(pinned,"北京",ClockZones.BEIJING);
        addClock(pinned,"美国·纽约",ClockZones.NEW_YORK);
        LinearLayout.LayoutParams pinnedLp=new LinearLayout.LayoutParams(-1,-2);
        pinnedLp.setMargins(dp(watch?6:11),dp(watch?4:9),dp(watch?6:11),0);
        page.addView(pinned,pinnedLp);

        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        scroll.setVerticalScrollBarEnabled(false);
        root=col();root.setPadding(dp(watch?10:17),dp(watch?9:15),dp(watch?10:17),dp(32));
        scroll.addView(root);
        scrollView=scroll;
        page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        if(watch){
            // Wear OS: a glanceable home is shown before full schedules or settings.
            // The fixed three-zone clocks above remain visible while this section scrolls.
            addWatchOverview();
            TextView down=text("↑ 上滑查看完整时间表和提醒设置",10,SOFT,false);
            down.setGravity(Gravity.CENTER);
            margin(root,down,16);
        }else{
            TextView h=text("BTC  MARKET CLOCK",20,MINT,true);h.setGravity(Gravity.CENTER);
            margin(root,h,8);
            TextView sub=text("以下事件与通知均以阿根廷时间为基准",12,SOFT,false);
            sub.setGravity(Gravity.CENTER);margin(root,sub,16);
        }

        // Full three-zone schedules live below the compact Wear overview.
        addFundingSchedule();
        addUsStockSchedule();
        // On watches, settings are reached by swiping below the main overview and schedules,
        // without having to scroll through a long history of event cards first.
        if(watch)addSettingsSection();

        List<MarketEvent> all=MarketCalendar.all(this,Instant.now(),46);
        ArrayList<MarketEvent> visible=new ArrayList<>();
        for(MarketEvent e:all)if(Prefs.enabled(this,e.type))visible.add(e);
        int count=Math.min(visible.size(),watch?7:14);
        TextView head=text("未来重要时间（阿根廷为准） · 各事件可设15/30分钟",watch?13:16,WHITE,true);
        margin(root,head,9);
        if(count==0)margin(root,text("没有已启用的近期事件，请检查提醒开关。",13,SOFT,false),12);
        for(int i=0;i<count;i++) addEventCard(visible.get(i),i==0);

        TextView macroHead=text("宏观重点 / 期权到期（未来45天）",watch?13:16,WHITE,true);
        margin(root,macroHead,8);
        int macroCount=0;
        for(MarketEvent e:visible){
            if(!e.high)continue;
            if(macroCount>=(watch?4:7))break;
            addEventCard(e,false);
            macroCount++;
        }
        if(macroCount==0)margin(root,text("当前45天内没有可显示的已启用重点事件。",watch?10:12,SOFT,false),12);

        if(!watch)addSettingsSection();

        long synced=Prefs.get(this).getLong("last_sync",0);
        String syncState=synced==0?"首次联网同步尚未完成（已预置部分官方日历）":
                "宏观日历同步（阿根廷）："+MarketCalendar.format(Instant.ofEpochMilli(synced),ClockZones.ARGENTINA);
        TextView foot=text(syncState+"\n美国数据发布时间可能变更；以发布机构的最新公告为准。\n资金费率是默认 8 小时周期，不代表全部合约。",
                watch?9:11,SOFT,false);margin(root,foot,8);
        updateClocks();
        if(previousScroll>0)scroll.post(()->scroll.scrollTo(0,previousScroll));
    }
    private void addSettingsSection(){
        TextView settingHead=text("提醒设置",watch?13:17,WHITE,true);
        margin(root,settingHead,9);
        Button fold=button(showSettings?"收起设置 ▲":"展开设置 ▼");
        fold.setOnClickListener(v->{showSettings=!showSettings;render();});
        margin(root,fold,10);
        if(showSettings)settingsArea();
    }

    /** Wear home: pinned triple clocks plus two immediate actionable market checkpoints. */
    private void addWatchOverview(){
        Instant now=Instant.now();
        List<MarketEvent> upcoming=MarketCalendar.all(this,now,9);
        MarketEvent nextFunding=null, nextMarket=null;
        for(MarketEvent e:upcoming){
            if(nextFunding==null && e.type.equals("funding"))nextFunding=e;
            if(nextMarket==null && (e.type.equals("nyse_open") || e.type.equals("nyse_afternoon") || e.type.equals("nyse_close")))nextMarket=e;
            if(nextFunding!=null && nextMarket!=null)break;
        }
        LinearLayout overview=col();overview.setBackground(shape(CARD2,13));
        padding(overview,10,7);
        if(nextFunding!=null){
            addWatchCheckpoint(overview,"下一次资金费率",nextFunding);
        }
        if(nextMarket!=null){
            View separator=new View(this);separator.setBackgroundColor(0xff32454c);
            LinearLayout.LayoutParams line=new LinearLayout.LayoutParams(-1,dp(1));
            line.topMargin=dp(5);line.bottomMargin=dp(5);
            overview.addView(separator,line);
            addWatchCheckpoint(overview,nextMarket.title,nextMarket);
        }
        if(nextFunding==null && nextMarket==null){
            margin(overview,text("暂无近期事件，请下滑检查提醒设置。",11,SOFT,false),2);
        }
        margin(root,overview,4);
    }
    private String watchShort(Instant instant,ZoneId zone){
        ZonedDateTime value=instant.atZone(zone);
        LocalDate argentinaDate=instant.atZone(ClockZones.ARGENTINA).toLocalDate();
        long dayOffset=java.time.temporal.ChronoUnit.DAYS.between(argentinaDate,value.toLocalDate());
        String suffix=dayOffset==1?"次日":dayOffset==-1?"前日":dayOffset==0?"":(dayOffset>0?"+"+dayOffset+"日":dayOffset+"日");
        return value.format(DateTimeFormatter.ofPattern("HH:mm",Locale.US))+suffix;
    }
    private void addWatchCheckpoint(LinearLayout parent,String title,MarketEvent e){
        // Three compact lines per checkpoint keep key content near the top on a small round display.
        TextView countdown=text(title+" · 距 "+MarketCalendar.countdown(e.at,Instant.now()),10,ORANGE,true);
        countdown.setTag(title+" · 距");
        margin(parent,countdown,2);
        TextView argentina=text("阿根廷  "+ClockZones.shortLabel(e.at,ClockZones.ARGENTINA)+" · 提前"+Prefs.lead(this,e.type,e.at)+"分",11,MINT,true);
        margin(parent,argentina,1);
        TextView other=text("北京 "+watchShort(e.at,ClockZones.BEIJING)
                +"  ·  纽约 "+watchShort(e.at,ClockZones.NEW_YORK),9,SOFT,false);
        other.setSingleLine(true);
        other.setEllipsize(android.text.TextUtils.TruncateAt.END);
        margin(parent,other,1);
        activeEvents.add(e);countdownLabels.add(countdown);
    }

    /** Today's three Argentina-local settlement times, all converted from the same instant. */
    private void addFundingSchedule(){
        LocalDate today=Instant.now().atZone(ClockZones.ARGENTINA).toLocalDate();
        TextView headline=text("资金费率时间表 · 阿根廷每日 05:00 / 13:00 / 21:00",watch?12:15,WHITE,true);
        margin(root,headline,7);
        LinearLayout panel=col();panel.setBackground(shape(CARD,14));padding(panel,watch?9:13,watch?7:10);
        for(int h:new int[]{5,13,21}){
            Instant at=ClockZones.fundingOnArgentinaDate(today,h);
            String hour=String.format(Locale.US,"%02d:00",h);
            TextView arg=text("阿根廷  "+today+"  "+hour,watch?11:13,MINT,true);
            margin(panel,arg,1);
            TextView other=text("北京 "+ClockZones.shortLabel(at,ClockZones.BEIJING)
                    +"  ·  纽约 "+ClockZones.shortLabel(at,ClockZones.NEW_YORK),watch?10:12,SOFT,false);
            margin(panel,other,watch?6:7);
        }
        margin(root,panel,watch?10:14);
    }
    /** Closest upcoming NYSE session; holidays and early close come from MarketCalendar. */
    private void addUsStockSchedule(){
        Instant now=Instant.now();
        List<MarketEvent> events=MarketCalendar.all(this,now,12);
        MarketEvent nextOpen=null;
        for(MarketEvent e:events)if(e.type.equals("nyse_open")){nextOpen=e;break;}
        if(nextOpen==null)return;
        LocalDate session=nextOpen.at.atZone(ClockZones.NEW_YORK).toLocalDate();
        TextView h=text("下一美股交易日 · "+session+"（纽约日期）",watch?12:15,WHITE,true);
        margin(root,h,7);
        LinearLayout panel=col();panel.setBackground(shape(CARD,14));padding(panel,watch?9:13,watch?7:10);
        for(MarketEvent event:events){
            if(!event.at.atZone(ClockZones.NEW_YORK).toLocalDate().equals(session))continue;
            if(!event.type.equals("nyse_open") && !event.type.equals("nyse_afternoon") && !event.type.equals("nyse_close"))continue;
            String name=event.type.equals("nyse_open")?"正式开盘":event.type.equals("nyse_afternoon")?"下午观察":"正式收盘";
            if(event.type.equals("nyse_close") && event.title.contains("提前"))name="提前收盘";
            margin(panel,text(name+" · 阿根廷 "+ClockZones.shortLabel(event.at,ClockZones.ARGENTINA),watch?11:13,MINT,true),1);
            margin(panel,text("北京 "+ClockZones.shortLabel(event.at,ClockZones.BEIJING)
                    +"  ·  纽约 "+ClockZones.shortLabel(event.at,ClockZones.NEW_YORK),watch?10:12,SOFT,false),watch?5:6);
        }
        margin(root,panel,watch?12:17);
    }
    private void addEventCard(MarketEvent e,boolean first){
        LinearLayout card=col();card.setBackground(shape(first?CARD2:CARD,14));
        padding(card,watch?9:13,watch?7:10);
        TextView title=text((e.high?"● ":"○ ")+e.title,watch?13:15,e.high?ORANGE:WHITE,true);
        margin(card,title,watch?3:4);
        TextView device=text("阿根廷  "+MarketCalendar.format(e.at,ClockZones.ARGENTINA),watch?11:13,MINT,true);
        margin(card,device,2);
        TextView times=text("北京 "+MarketCalendar.format(e.at,MarketCalendar.BEIJING)
                +"\n纽约 "+MarketCalendar.format(e.at,MarketCalendar.NEW_YORK),watch?10:12,SOFT,false);
        margin(card,times,watch?3:5);
        TextView cd=text("距事件  "+MarketCalendar.countdown(e.at,Instant.now())+" · 提前"+Prefs.lead(this,e.type,e.at)+"分提醒",watch?11:13,ORANGE,true);
        margin(card,cd,2);
        card.addView(text(e.detail,watch?9:11,SOFT,false));
        margin(root,card,watch?7:9);
        cd.setTag("距事件");
        activeEvents.add(e);countdownLabels.add(cd);
    }
    private void addClock(LinearLayout parent,String label,ZoneId zone){
        boolean primary=ClockZones.ARGENTINA.equals(zone);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView name=text(label,watch?10:13,primary?MINT:SOFT,primary);
        row.addView(name,new LinearLayout.LayoutParams(0,-2,watch?1.18f:1.0f));
        TextView value=text("",watch?(primary?14:12):(primary?19:16),primary?MINT:WHITE,true);
        value.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);
        row.addView(value,new LinearLayout.LayoutParams(0,-2,watch?1.75f:1.25f));
        value.setTag(zone);clockLabels.add(value);
        margin(parent,row,watch?2:4);
    }
    private void updateClocks(){
        Instant now=Instant.now();
        // The watch overview groups funding before NYSE, so the first item is not
        // necessarily the soonest deadline. Rebuild when *any* displayed event expires.
        for(MarketEvent e:activeEvents){
            if(!now.isBefore(e.at.plusSeconds(5))){
                render();
                return;
            }
        }
        for(TextView t:clockLabels){
            ZoneId zone=(ZoneId)t.getTag();
            t.setText(now.atZone(zone).format(DateTimeFormatter.ofPattern("MM/dd HH:mm",Locale.US)));
        }
        for(int i=0;i<countdownLabels.size();i++){
            TextView view=countdownLabels.get(i);
            String prefix=view.getTag() instanceof String?(String)view.getTag():"距事件";
            MarketEvent e=activeEvents.get(i);
            view.setText(prefix+"  "+MarketCalendar.countdown(e.at,now)
                    +(prefix.equals("距事件")?" · 提前"+Prefs.lead(this,e.type,e.at)+"分提醒":""));
        }
    }
    private Button button(String title){
        Button b=new Button(this);b.setText(title);b.setTextColor(WHITE);b.setTextSize(watch?11:13);
        b.setAllCaps(false);b.setBackground(shape(CARD2,12));
        b.setMinimumHeight(dp(watch?32:40));return b;
    }
    private void settingsArea(){
        LinearLayout panel=col();panel.setBackground(shape(CARD,16));padding(panel,watch?9:13,12);
        TextView top=text("提醒时间 · 阿根廷为准",watch?12:14,WHITE,true);margin(panel,top,6);
        TextView tip=text("每项事件分别选择提前15或30分钟；先用下面两个按钮批量设置，再按需逐项修改。手机/手表可独立通知。",watch?10:12,SOFT,false);
        margin(panel,tip,6);
        LinearLayout chooser=new LinearLayout(this);chooser.setOrientation(LinearLayout.HORIZONTAL);
        for(int lead:new int[]{15,30}) {
            Button b=button("全部提前"+lead+"分钟");
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(watch?38:44),1);p.rightMargin=dp(4);
            chooser.addView(b,p);
            b.setOnClickListener(v->{Prefs.setLead(this,lead);changed();});
        }
        margin(panel,chooser,10);
        option(panel,"notify_here","在此设备接收通知",Prefs.notificationsEnabled(this));
        option(panel,"funding","资金费率（每天3次）",true);
        option(panel,"nyse_open","美股 09:30 开盘",true);
        option(panel,"nyse_afternoon","美股 13:00 下午观察",true);
        option(panel,"nyse_close","美股 16:00 收盘",true);
        option(panel,"nyse_pre","美股 08:00 盘前观察",false);
        option(panel,"expiry","BTC 月度期权到期",true);
        option(panel,"fomc","FOMC 利率决议",true);
        option(panel,"cpi","CPI 通胀数据",true);
        option(panel,"nfp","非农就业数据",true);
        option(panel,"pce","PCE 通胀数据",true);
        option(panel,"ppi","PPI 通胀数据（可选）",false);
        option(panel,"gdp","GDP 首次预估（可选）",false);
        margin(root,panel,10);
        Button sync=button("联网同步 BLS / BEA 官方数据日历");
        sync.setOnClickListener(v->{sync.setEnabled(false);sync.setText("正在读取官方日历…");
            new Thread(()->{
                OfficialCalendars.Result r=OfficialCalendars.refresh(getApplicationContext());
                runOnUiThread(()->{Toast.makeText(this,r.success()?"已更新：BLS "+r.bls+"，BEA "+r.bea:"官方日历更新失败，请检查网络",Toast.LENGTH_LONG).show();render();});
            },"ManualCalendarSync").start();
        });margin(root,sync,8);
        Button test=button("测试本机提醒（约10秒后）");
        test.setOnClickListener(v->{requestNotificationPermission();Scheduler.test(this);Toast.makeText(this,"测试提醒已安排",Toast.LENGTH_SHORT).show();});
        margin(root,test,8);
        Button exact=button(Scheduler.exactAllowed(this)?"精确提醒权限：已允许":"开启精确提醒权限（建议）");
        exact.setOnClickListener(v->{
            if(Build.VERSION.SDK_INT>=31 && !Scheduler.exactAllowed(this)) {
                try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}
                catch(Exception e){Toast.makeText(this,"请在系统设置中允许闹钟与提醒",Toast.LENGTH_LONG).show();}
            }else Toast.makeText(this,"精确提醒已启用",Toast.LENGTH_SHORT).show();
        });margin(root,exact,8);
        TextView help=text("关闭精确提醒权限或限制后台运行时，Android 可能延迟通知。手机和手表可独立工作；已配对时通过 Google Play 服务同步开关和官方日历。",
                watch?10:12,SOFT,false);margin(root,help,8);
    }
    private void option(LinearLayout parent,String key,String label,boolean defaultValue){
        Switch sw=new Switch(this);sw.setText(label);sw.setTextSize(watch?11:13);sw.setTextColor(WHITE);
        sw.setPadding(0,dp(watch?4:6),0,dp(watch?4:6));
        sw.setChecked(Prefs.get(this).getBoolean(key,defaultValue));
        sw.setOnCheckedChangeListener((compound,checked)->{Prefs.setEnabled(this,key,checked);changed();});
        margin(parent,sw,1);
        // Device notification master switch does not have a lead time of its own.
        if("notify_here".equals(key))return;
        if("funding".equals(key)) {
            for(int hour:new int[]{5,13,21}) {
                String settlementKey=String.format(Locale.US,"funding_%02d",hour);
                addLeadControls(parent,settlementKey,String.format(Locale.US,"阿根廷 %02d:00 结算",hour),sw.isChecked());
            }
        } else addLeadControls(parent,key,null,sw.isChecked());
    }
    private void addLeadControls(LinearLayout parent,String key,String caption,boolean enabled){
        if(caption!=null){
            TextView label=text(caption,watch?10:12,SOFT,false);
            margin(parent,label,watch?1:2);
        }
        LinearLayout leadRow=new LinearLayout(this);leadRow.setOrientation(LinearLayout.HORIZONTAL);
        int selected=Prefs.lead(this,key);
        for(int minutes:new int[]{15,30}){
            Button b=button((selected==minutes?"✓ ":"")+"提前"+minutes+"分");
            b.setTextSize(watch?10:12);
            b.setEnabled(enabled);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(watch?32:39),1);
            lp.rightMargin=dp(4);
            leadRow.addView(b,lp);
            b.setOnClickListener(v->{Prefs.setTypeLead(this,key,minutes);changed();});
        }
        margin(parent,leadRow,watch?7:9);
    }
    private void changed(){Scheduler.plan(this);DataBridge.push(this);render();}
    private void requestNotificationPermission(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},88);
    }
}
