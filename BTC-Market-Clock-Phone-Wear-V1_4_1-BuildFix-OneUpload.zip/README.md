# BTC Market Clock — 手机 + Wear OS 轻量市场时间助手（V1.4）

两个独立可安装的 Android APK：`phone`（手机）和 `wear`（Wear OS 手表），共享时间算法和提醒配置。采用原生 Java、系统 AlarmManager / JobScheduler，没有 WebView、K 线、后台行情轮询、钱包授权或交易 API Key。

## 手表主页布局（V1.4）

- **手表首屏 = 三地时间 + 即时市场速览**：固定顶部三地实时钟，优先按「阿根廷 / 北京 / 美国纽约」显示；下方紧凑展示**下一次 8 小时资金费率结算**（并列出阿根廷每日 05:00/13:00/21:00）及**最近的美股交易节点**（开盘／下午观察／收盘），包括三地日期、时刻和动态倒计时。
- **向上滑动手表屏幕**查看完整资金费率表、下一交易日美股时间、未来事件、宏观风险、提醒设置与权限等；设置区默认折叠，点击「展开设置」使用。整页无需进入额外二级页面。
- 手表专用紧凑主页不会改变手机界面；顶部三地时钟在下方滚动时仍保持置顶。屏幕直径及系统字体大小不同，首屏可见的速览行数略有差异，但设置始终位于下方。

## 主页面

- **主页固定置顶**三地实时钟，始终按「阿根廷（America/Argentina/Buenos_Aires）→ 北京（Asia/Shanghai）→ 美国纽约（America/New_York）」顺序显示。滚动下方事件表时，三地时钟不随页面滚走。
- **所有事件和系统通知的首行都是阿根廷当地日期与时刻**，随后分别标明北京时间和美国纽约时间；自动处理美国夏令时、冬令时及跨日期，不采用设备自动时区来改变提醒基准。
- 资金费率独立时间表、下一美股交易日时间表，以及未来市场节点均显示阿根廷、北京、纽约三地时间；另设未来 45 天的「宏观重点／期权到期」板块。
- 每一项显示**阿根廷（主）/北京/纽约**时间及倒计时。
- 通知可对**每一个事件类别单独设置提前 15 分钟或提前 30 分钟**。例如阿根廷 05:00 资金费率 15 分钟、13:00 资金费率 30 分钟、美股开盘 30 分钟、CPI 30 分钟；也有「全部提前 15 / 30 分钟」批量设置。全部从阿根廷时间换算，通知详细信息附三地时刻。
- 每类事件有独立开关和独立提前 15 / 30 分钟设置，且三次资金费率各有独立提前时间；手机和手表可选择是否各自发通知。
- 官方宏观日历首次运行尝试同步，之后 Android JobScheduler 约每 12 小时调度更新；也可以手动刷新（具体运行时间由系统安排）。
- 同一 Google 账号配对的手机/手表使用 Wear OS Data Layer 同步提醒选项与日历（需 Google Play 服务，设备和配对状态允许；仍可独立运行）。
- 测试按钮可在约 10 秒后发出本机系统通知。

## 时间对照（参考）

以下时间以**阿根廷当地时间为主**。

| 项目 | 阿根廷时间 | 北京时间 | 美国纽约时间 |
|---|---|---|---|
| 资金费率1 | 每天 05:00 | 当天 16:00 | 冬令时 03:00 / 夏令时 04:00 |
| 资金费率2 | 每天 13:00 | 次日 00:00 | 冬令时 11:00 / 夏令时 12:00 |
| 资金费率3 | 每天 21:00 | 次日 08:00 | 冬令时 19:00 / 夏令时 20:00 |
| 美股正式开盘 | 美国夏令时 10:30 / 冬令时 11:30 | 夏令时 21:30 / 冬令时 22:30 | 09:30 |
| 美股下午观察点 | 美国夏令时 14:00 / 冬令时 15:00 | 夏令时次日 01:00 / 冬令时次日 02:00 | 13:00 |
| 美股正式收盘 | 美国夏令时 17:00 / 冬令时 18:00 | 夏令时次日 04:00 / 冬令时次日 05:00 | 16:00 |

**注意：** 美国夏令时/冬令时转换自动按纽约的 `America/New_York` 时区规则计算，阿根廷的基准时区固定为 `America/Argentina/Buenos_Aires`。交易所特别提前收盘时，使用提前收盘事件代替常规收盘；资金费率为通用 8 小时例子。

## 事件

| 类型 | 时间算法 | 默认 |
|---|---|---|
| Binance 8小时资金费率 | 00:00 / 08:00 / 16:00 UTC，每天 | 开 |
| NYSE 美股正式开盘 | 09:30 ET，交易日 | 开 |
| NYSE 下午观察点 | 13:00 ET，交易日（**不是下午重新开盘**） | 开 |
| NYSE 正式收盘 | 16:00 ET，交易日；官方特别提前收盘日按 13:00 ET | 开 |
| NYSE 盘前观察点 | 08:00 ET，交易日 | 关 |
| BTC 月/季度期权到期 | Deribit 标准月末周五 08:00 UTC；3/6/9/12 月季度 | 开 |
| 美国 CPI / 非农 NFP / PCE | 具体发布日取官方在线日历，未联网时仅有部分离线预置 | 开 |
| FOMC 利率决议 | 2026/27 已公布/暂定的利率决策日 14:00 ET | 开 |
| 美国 PPI / GDP 首次估值 | 取 BLS / BEA 官方在线日历 | 关 |

### 日历可靠性与限制

- Binance 的每 8 小时资金费率是**默认**周期。实际交易对可能使用 1 小时/4 小时等不同周期；此 App **不查询具体交易对**的 `nextFundingTime`。交易前应核对交易所实时合约信息。
- 美股没有正式「下午重新开盘」。13:00 ET 是用户设定的观察点。普通交易日 09:30–16:00 ET；固定节假日采用 NYSE 日历规则，已核对 **2026–2028** 的特殊提前收盘日期。临时停市、特别安排并不能由离线规则完全覆盖。
- BLS CPI / 非农 / PPI：`https://www.bls.gov/schedule/news_release/bls.ics`；BEA PCE / GDP：`https://www.bea.gov/news/schedule/ics/online-calendar-subscription.ics`。离线预置 CPI / 非农覆盖 2026 年 12 月至 2027 年 12 月，PCE 只预置 2026-11-25 和 2026-12-23；联网更新成功后优先采用官方日历，不按「每月第一个周五」猜测非农日期。
- FOMC 官方已公布的 2026 年 12 月 9 日及 2027 年 7 个利率决策日离线预置；**2027 年 10 月 26–27 日为政策战略会议，不作为常规利率决议提醒**。FOMC 变更目前不自动抓取，后续年份需更新 App 的预置表。FOMC 14:00 ET 是常规决议时间，临时会议或特殊发布时间无法自动识别。
- 期权到期可能与 08:00 UTC 的资金费率结算同时发生，会有两个不同的事件提醒；期权到期不代表币价必然向任何方向运行。
- Android 12 及更新版本建议允许**闹钟与提醒/精确闹钟**；Android 13+ 还需要允许通知。未授权或电量优化严格时，提醒可能延迟。手机和手表首次安装后分别点击「测试提醒」。
- 此版本只提示时间节点，不判断交易方向、不触发任何交易，也不保证事件发生时市场一定波动。

## 从 ZIP 到 APK — GitHub Actions 自动编译

1. 打开 <https://github.com/new>，新建空仓库，例如：`BTC-Market-Clock-Phone-Wear`（不必勾选初始化 README）。
2. 把 ZIP **解压后**的项目文件上传到仓库根目录，确保仓库可直接看到 `settings.gradle`、`phone/`、`wear/`、`.github/workflows/android.yml` 等文件；**不要只上传 ZIP 文件本身**。
3. 在 GitHub 顶部点击 **Actions** → **Build Android Phone and Wear OS APKs** → **Run workflow**。推送到 main/master 分支时也会自动编译。
4. 编译完成后在该 workflow 页面底部 **Artifacts** 下载：
   - `BTC-MarketClock-Phone-Debug`：手机 APK (`phone-debug.apk`)
   - `BTC-MarketClock-Wear-Debug`：Wear OS APK (`wear-debug.apk`)
5. 手机上安装 Phone 版；手表通过 ADB 或 Wear OS 调试桥安装 Wear 版。安装后分别允许通知和精确闹钟权限、打开 App 检查时间、点击测试提醒。

工程使用 Android Gradle Plugin 8.7.3、Gradle 8.10.2、JDK 17、compileSdk 35、Play Services Wearable 19.0.0。Actions 配置使用 `gradle/actions/setup-gradle@v4` 下载 Gradle，因此**不需要 Gradle Wrapper**。两个 APK 在同一个工作流内使用同一套 Debug 签名；单独在不同电脑重新构建的 Debug APK 签名可能不同。

本项目提供的是**可提交到 GitHub 自动编译的源码**，不是已经在当前环境安装测试或实际成功编译过的 APK。建议首次构建成功后在手机及手表分别测试通知、断网、重启、夏令时切换及系统休眠下的到达时间。

## 项目结构

```
.github/workflows/android.yml  GitHub 自动构建两个 APK
phone/                       Android 手机入口和配置
wear/                        Wear OS 手表入口和配置
shared/src/main/java/.../    共享时间、官方日历、提醒、同步与界面逻辑
```

## 参考（官方）

- NYSE 正式交易时段 / 2026–2028 休市与提前收盘：<https://www.nyse.com/trade/hours-calendars>
- Binance USDⓈ-M 默认资金费率结算周期：<https://www.binance.com/en/support/faq/detail/360033525031>
- BLS CPI：<https://www.bls.gov/schedule/news_release/cpi.htm>
- BLS 非农就业：<https://www.bls.gov/schedule/news_release/empsit.htm>
- BEA 官方日历：<https://www.bea.gov/news/schedule/icalendar>
- FOMC 会议安排：<https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm>
- Deribit 期权到期规则：<https://support.deribit.com/hc/en-us/articles/25944688876957-Contract-Introduction-Policy>
- CME 期货加密产品已 24/7 交易、定期维护：<https://www.cmegroup.com/trading-hours.html>

## 2026-11-21 · GitHub 编译工作流修复（V1.4.1 BuildFix）

- 根据用户截图，原版在 `android-actions/setup-android@v3` 步骤失败，尚未进入 Gradle/Java 编译。
- 新版 `.github/workflows/android.yml` 移除该 action，固定 `ubuntu-24.04`，优先使用 Runner 预装 Android SDK；若缺少 API 35 或 Build Tools 35.0.0 才用 sdkmanager 安装。
- 保留原手机和 Wear OS 功能，不改时区、事件、提醒、首页布局。
- 操作：解压完整 ZIP 上传到 GitHub 仓库**根目录**，覆盖现有文件（特别是 `.github/workflows/android.yml`），提交并在 Actions 中重新运行。
- 如再次失败，请展开**第一个红色步骤**，滚动到日志最下方截图（包括 `Error:` 或 `FAILURE:` 行）。本包未在当前容器实际构建 APK，最终是否成功需以 GitHub 运行结果为准。
